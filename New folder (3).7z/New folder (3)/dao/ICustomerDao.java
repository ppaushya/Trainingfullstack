package org.cap.dao;

import java.util.List;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface ICustomerDao {

	public List<Customer> getAllCustomers();
	public void createCustomer(Customer customer);
	public void createAccount(Account account);
	//public Set<Account> getAllAccounts();
	
}
