package org.cap.dao;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.Address;
import org.cap.model.Customer;

public class CustomerDoaimpl implements ICustomerDoa {
	 List<Customer> customers=new ArrayList();
	 Address address=new Address();
			 private static List<Customer> dummy_db() {
			// TODO Auto-generated method stub
			
			return null;
			 
		}

}
