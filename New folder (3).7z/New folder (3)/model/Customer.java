package org.cap.model;

import java.time.LocalDate;

import java.util.Set;

public class Customer {
private int customer_id;
private String first_name;
private String last_name;
private String email_id;
private String mobile_no;
private LocalDate dob;
private Address address;
private Set<Account> account;
public Customer() {
	
}

public Customer(int customer_id, String first_name, String last_name, String email_id, String mobile_no, LocalDate dob,
		Address address, Set<Account> account) {
	super();
	this.customer_id = customer_id;
	this.first_name = first_name;
	this.last_name = last_name;
	this.email_id = email_id;
	this.mobile_no = mobile_no;
	this.dob = dob;
	this.address = address;
	this.account = account;
}

public Customer(Set<Account> account) {
	super();
	this.account = account;
}

public Customer(int customer_id, String first_name, String last_name, LocalDate dob,  String email_id, String mobile_no, Address address) {
	// TODO Auto-generated constructor stub
	super();
	this.customer_id = customer_id;
	this.first_name = first_name;
	this.last_name = last_name;
	this.email_id = email_id;
	this.mobile_no = mobile_no;
	this.dob = dob;
	this.address = address;
	
}
public int getCustomer_id() {
	return customer_id;
}
public void setCustomer_id(int customer_id) {
	this.customer_id = customer_id;
}
public String getFirst_name() {
	return first_name;
}
public void setFirst_name(String first_name) {
	this.first_name = first_name;
}
public String getLast_name() {
	return last_name;
}
public void setLast_name(String last_name) {
	this.last_name = last_name;
}
public String getEmail_id() {
	return email_id;
}
public void setEmail_id(String email_id) {
	this.email_id = email_id;
}
public String getMobile_no() {
	return mobile_no;
}
public void setMobile_no(String mobile_no) {
	this.mobile_no = mobile_no;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}
public Set<Account> getAccount() {
	return account;
}
public void setAccount(Set<Account> account) {
	this.account = account;
}
@Override
public String toString() {
	return "Customer [customer_id=" + customer_id + ", first_name=" + first_name + ", last_name=" + last_name
			+ ", email_id=" + email_id + ", mobile_no=" + mobile_no + ", dob=" + dob + ", address=" + address
			+ ", account=" + account + "]";
}

}
