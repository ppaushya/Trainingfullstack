package org.cap.model;

public enum AccountType {
SAVINGS,CURRENT,RD,FD;
}
