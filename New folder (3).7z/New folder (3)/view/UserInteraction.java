package org.cap.view;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.AccountType;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.CustomerServiceimpl;
import org.cap.service.ICustomerService;
import org.cap.util.Utility;

public class UserInteraction {
Scanner scanner=new Scanner(System.in);
ICustomerService customerService=new CustomerServiceimpl();

public Customer getCustomerDetails() {
	Customer customer=new Customer();
	customer.setCustomer_id(Utility.generateNumber());
	customer.setFirst_name(promptfname());
	customer.setLast_name(promptLname());
	customer.setMobile_no(promptmobileNo());
	customer.setEmail_id(promptemail());
	customer.setDob(promptDOB());
	customer.setAddress(promptAddress());
	//customer.setAccount(promptAccount());
	
	return customer;
	
}

public Set<Account> getAccountDetails(int customerId) {
	// TODO Auto-generated method stub
	
	
	Set<Account> accounts=new LinkedHashSet<>();
	Account account=new Account();
	String response;
	do {
	account.setAccountNumber(Utility.generateNumber());
	System.out.println("Enter Accounttype 1.Savings 2.Current 3.RD 4.FD");
	int choice=scanner.nextInt();
	account.setAccountType(assignAccounttype(choice));	
	account.setOpeningDate(LocalDate.now());
	System.out.println("Enter opening balance");
	double bal=scanner.nextDouble();
	account.setOpeningBalance(bal);
	System.out.println("Enter description");
	String des=scanner.next();
	account.setDescription(des);
	accounts.add(account);
	System.out.println("do u want to add more accounts[y/n]");
	 response=scanner.next();
	}while(response.charAt(0)=='Y'||response.charAt(0)=='y');
	
	return accounts;
	
}

private AccountType assignAccounttype(int choice) {
	// TODO Auto-generated method stub
	
	switch(choice) {
	case 1:
		return AccountType.SAVINGS;
	case 2:
		return AccountType.CURRENT;
		
	case 3:
		return AccountType.RD;
		
	case 4:
		return AccountType.FD;
	default:
		System.out.println("invalid account type");
		System.exit(0);
	
	}
	return null;
}

//private Set<Account> promptAccount() {
//	// TODO Auto-generated method stub
//	Set<Account> account=new HashSet();
//	System.out.println("Enter Address");
//	account.add(scanner.next());
//	return account;
//	
//}

public Address promptAddress() {
	// TODO Auto-generated method stub
	Address add=new Address();
	System.out.println("Enter Address");
	System.out.println("Enter AddressLine1");
	add.setAddressLine1(scanner.next());
	System.out.println("Enter AddressLine2");
	add.setAddressLine1(scanner.next());
	System.out.println("Enter city");
	add.setAddressLine1(scanner.next());
	System.out.println("Enter State");
	add.setAddressLine1(scanner.next());
	System.out.println("Enter pin code");
	add.setPinCode(scanner.next());
	return add;
	
}

public LocalDate promptDOB() {
	// TODO Auto-generated method stub
	LocalDate dob;String DOB;
	boolean flag=false;
	
	do {
		System.out.println("Enter date of birth (dd-mm-yyyy)");
		DOB=scanner.next();
		int date=Integer.parseInt(DOB.substring(0, 2));
		int month=Integer.parseInt(DOB.substring(3, 5));
		int year=Integer.parseInt(DOB.substring(6, 10));
		dob=LocalDate.of(year, month,date);
		
		if(DOB.matches("[0-9]{2}[-]{1}[0-9]{2}[-]{1}[0-9]{4}")) {
			flag=true;
		}
		if(!flag)
			System.out.println("please enter valid date of birth");		
	}while(!flag);
	return dob;
	
}

public String promptemail() {
	// TODO Auto-generated method stub
	String emailid;
	boolean flag=false;
	
	do {
		System.out.println("Enter emailId");
		emailid=scanner.next();
		if(emailid.matches("[a-z$^*0-9]{5}[@]{1}[a-zA-Z.]{4}")) {
			flag=true;
		}
		if(!flag)
			System.out.println("please enter valid emailid");		
	}while(!flag);
	return emailid;
	
}

public String promptmobileNo() {
	// TODO Auto-generated method stub
	boolean flag=false;
	String mnumber;
	do {
		System.out.println("Enter mobileno");
		mnumber=scanner.next();
		if(mnumber.matches("[0-9]{10}")) {
			flag=true;
		}
		if(!flag)
			System.out.println("please enter valid mobile number");		
	}while(!flag);
	return mnumber;
	
}

public String promptfname() {
	// TODO Auto-generated method stub
	boolean flag=false;
	String name;
	do {
		System.out.println("Enter firstName");
		name=scanner.next();
		flag=Utility.isValidName(name);
		if(!flag)
			System.out.println("please enter valid first name");		
	}while(!flag);
	return name;
}
public String promptLname() {
	// TODO Auto-generated method stub
	boolean flag=false;
	String name;
	do {
		System.out.println("Enter LastName");
		name=scanner.next();
		flag=Utility.isValidName(name);
		if(!flag)
			System.out.println("please enter valid Last name");		
	}while(!flag);
	return name;
}

public void printCustomers(List<Customer> customers) {
	System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
	System.out.println("-----------------------------------------------------------------------------");
	
	for(Customer customer:customers) {
		System.out.println(customer.getCustomer_id()
				+"\t\t"+customer.getFirst_name()+" " + customer.getLast_name()
				+"\t"+ customer.getEmail_id() + "\t" + customer.getMobile_no()+"\t" +customer.getAccount() );
	}
}

public void printError(String string) {
	// TODO Auto-generated method stub
	
}

public boolean validatecustomerId(int customerId) {
	
	int cust_id=customerId;
	boolean flag = false;
	for(int i=0;i<customerService.getAllCustomers().size();i++) {
		if(cust_id==customerService.getAllCustomers().get(i).getCustomer_id())
		{
			flag= true;
			break;
		}
	else {
			flag= false;
		}
		
	}
	return flag;
}
}
