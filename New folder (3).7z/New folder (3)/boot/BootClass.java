package org.cap.boot;

	import java.util.*;
	import java.util.Scanner;

import org.cap.model.Account;
import org.cap.model.Customer;
	import org.cap.service.CustomerServiceimpl;
import org.cap.service.ICustomerService;
	import org.cap.view.UserInteraction;

	public class BootClass {

		static Scanner scanner=new Scanner(System.in);
		
		public static void main(String[] args) {
			ICustomerService customerService=new CustomerServiceimpl();
			UserInteraction userInteraction=new UserInteraction();
			
			int  choice;
			String option;
			do {
			System.out.println("1.Create Customer");
			System.out.println("2.List Customers");
			System.out.println("3.Create account for existing Customers");
			System.out.println("4.perform transactions ");
			System.out.println("Enter Your choice:");
			choice=scanner.nextInt();
					
				switch(choice) {		
				case 1:
					
					int count=customerService.getAllCustomers().size();
					
					Customer customer=userInteraction.getCustomerDetails();
					customerService.createCustomer(customer);
					
					
				if(count<=customerService.getAllCustomers().size())
						userInteraction.printError("Customer Creation Error! Please Try Again!");
						
				
			    break;
				case 2:
					
					List<Customer> customers= customerService.getAllCustomers();
					userInteraction.printCustomers(customers);
					break;
				case 3:
					int customerId;
					System.out.println("enter customer id");
					customerId=scanner.nextInt();
					boolean flag;
					flag=userInteraction.validatecustomerId(customerId);
					if(flag==true)
					{
					Set<Account> acc=userInteraction.getAccountDetails(customerId);
					customerService.assignAccount(acc,customerId);
					}
					else {
						System.out.println("Please enter valid customer id");
					}
					break;
				

				default:
					System.out.println("Sorry! Invalid Choice");
					System.exit(0);
				
				}
				System.out.println("Do you wish to contine?[y|n]:");
				option=scanner.next();
				
			}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
			
			
			
			//System.out.println(customer);
		}

	}
	
