package org.cap.util;

public class Utility {
public static int generateNumber() {
	return (int)(Math.random()*1000/10);
	
}

public static boolean isValidName(String fname) {
	// TODO Auto-generated method stub
	boolean flag=false;
	String name=fname;
	if(fname.matches("[A-Za-z]{3,}")) {
		flag=true;
	}
	else
		flag=false;
	return flag;
}
}
