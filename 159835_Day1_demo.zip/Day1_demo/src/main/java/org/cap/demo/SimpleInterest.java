package org.cap.demo;
import  java.util.*;
public class SimpleInterest {

	 double principle;
	 float years;
	 float rate_of_interest;
	 //float rateOfInterest;
	 public void getData() {
		/* principle=4000;
		 years=3.3f;
		 rate_of_interest=0.0665f;
		 */
		 Scanner scanner=new Scanner(System.in);
		 principle=scanner.nextDouble();
		 years=scanner.nextFloat();
		 rate_of_interest=scanner.nextFloat();
		 //System.out.println()
		 scanner.close();
	 }
	 public double calculateInterest()
	 {
		 return principle*years*rate_of_interest;
		 
	 }
	

}
