package org.cap.demo;

public class Test {
	//instance variables
	int count;
    char ch;
    boolean flag;
    byte num;
    float pi;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int mynum=200;
		
        Test obj= new Test();
        obj.num=23;
        System.out.println(obj.ch);
        System.out.println(obj.flag);
        System.out.println(obj.count);
        System.out.println(obj.pi);
        System.out.println(obj.num);
        System.out.println("Mynum="+mynum);

	}

}
