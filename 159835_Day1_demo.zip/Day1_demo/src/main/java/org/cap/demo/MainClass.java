package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  SimpleInterest interest=new SimpleInterest();
  interest.getData();
  double simpleinter=interest.calculateInterest();
  System.out.println("Calculated interest is:"+simpleinter);
	}

}
