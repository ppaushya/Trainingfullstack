package org.cap.demo;

import java.util.Scanner;

public class student {
	
	String name;
	int marks1,marks2,marks3,marks4;
	public void getData()
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Name : ");
		name=scanner.next();
		System.out.println("Marks 1 are?");
		marks1=scanner.nextInt();
		System.out.println("marks 2 are?");
		marks2=scanner.nextInt();
		System.out.println("marks 3 are?");
		marks3=scanner.nextInt();
		System.out.println("marks 4 are?");
		marks4=scanner.nextInt();
		scanner.close();
	}
	
	public int findScore() {
		
		return marks1+marks2+marks3+marks4;
		
		
	}
	public float findAvg() {
		return (marks1+marks2+marks3+marks4)/4;
	}
	
	public void printStud() {
		int total;
		double avg;
		total=findScore();
		avg=findAvg();
		System.out.println("Name : "+name);
		System.out.println("marks1 : "+marks1);
		System.out.println("marks2 : "+marks2);
		System.out.println("marks3 : "+marks3);
		System.out.println("marks4 : "+marks4);
		System.out.println("Sum : "+total);
		System.out.println("AVG : "+ avg);
	}

	public static void main() {
		student s=new student();
		s.getData();
		s.printStud();
	}
}
