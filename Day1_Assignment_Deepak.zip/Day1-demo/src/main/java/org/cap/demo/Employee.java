package org.cap.demo;

import java.util.Scanner;

public class Employee {
					int empid;
				    String empName;
					int age;
					boolean isPermanent;
					String gender;
					String address;
			public void getData()
			{
				Scanner scanner =new Scanner(System.in);
				System.out.println("Enter Employee ID:");
				empid = scanner.nextInt();
				System.out.println("Enter Employee Name:");
			    empName = scanner.next();
				System.out.println("Age");
				age = scanner.nextInt();
				System.out.println("Is Permanent");
				isPermanent = scanner.nextBoolean();
				System.out.println("Gender:");
				gender = scanner.next();
				System.out.println("Address:");
				address = scanner.next();
				scanner.close();
			}
			
			public void printEmployee()
			{
				System.out.println(empid);
				System.out.println(empName);
				System.out.println(age);
				System.out.println(isPermanent);
				System.out.println(gender);
				System.out.println(address);
			}
			
			
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee obj = new Employee();
		obj.getData();
		obj.printEmployee();
		
	}

}
