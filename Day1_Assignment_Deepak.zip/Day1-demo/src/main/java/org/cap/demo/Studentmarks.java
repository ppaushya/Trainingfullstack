package org.cap.demo;

import java.util.Scanner;

public class Studentmarks {
			
			String name;
			int marks1;
			int marks2;
			int marks3;
			int marks4;
			public void getStudent()
			{
				Scanner scanner =new Scanner(System.in);
				System.out.println("Enter Student Name:");
			    name = scanner.next();
				System.out.println("Marks1");
				marks1 = scanner.nextInt();
				System.out.println("Marks2");
				marks2 = scanner.nextInt();
				System.out.println("Marks3");
				marks3 = scanner.nextInt();
				System.out.println("Marks4");
				marks4 = scanner.nextInt();
				scanner.close();
			}
			
			public void printStudentDetails()
			{
				System.out.println(name);
				System.out.println(marks1);
				System.out.println(marks2);
				System.out.println(marks3);
				System.out.println(marks4);
			}
			
			public int findScore()
			{
				int Score;
				Score = marks1+marks2+marks3+marks4;
				return Score;
			}
			
			public float findAverage()
			{
				Float Average;
				Average = (marks1+marks2+marks3+marks4)/4.0f;
				return Average;
			}
			
			

	public static void main(String[] args) {
		Studentmarks obj = new Studentmarks();
		obj.getStudent();
		obj.printStudentDetails();
		System.out.println(obj.findScore());
		System.out.println(obj.findAverage());

	}

}
