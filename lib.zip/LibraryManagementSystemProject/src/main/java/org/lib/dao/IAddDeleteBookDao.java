package org.lib.dao;

import java.util.List;

import org.lib.bean.BooksInventory;

public interface IAddDeleteBookDao {
	
	public void addBook(BooksInventory booksinventory);
	public List<BooksInventory> getallbooks();
	public void deleteBook(String bookId);

}
