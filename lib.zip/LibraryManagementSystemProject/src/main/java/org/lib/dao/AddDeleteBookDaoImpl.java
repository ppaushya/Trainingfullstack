package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.lib.bean.BooksInventory;


public class AddDeleteBookDaoImpl implements IAddDeleteBookDao {
	
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void addBook(BooksInventory booksinventory) {
		
		String sql = "insert into BooksInventory values(?,?,?,?,?,?)";
				
		try(Connection connection=getConnection())
		{
			PreparedStatement st=connection.prepareStatement(sql);
			st.setString(1, booksinventory.getBook_id());
			st.setString(2, booksinventory.getBook_name());
			st.setString(3, booksinventory.getAuthor1());
			st.setString(4, booksinventory.getAuthor2());
			st.setString(5, booksinventory.getPublisher());
			st.setString(6, booksinventory.getYearofpub());
			
			
			int row=st.executeUpdate();

			if(row>0)
				System.out.println("Book has been inserted!");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
			
			
			
			
	}

	@Override
	public List<BooksInventory> getallbooks() {
		
		List<BooksInventory> lst = new ArrayList<>();
		String str="select * from BooksInventory;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet rs= statement.executeQuery();
			
			
			while(rs.next())
			{
				BooksInventory addbook = new BooksInventory();
				addbook.setBook_id(rs.getString(1));
				addbook.setBook_name(rs.getString(2));
				addbook.setAuthor1(rs.getString(3));
				addbook.setAuthor2(rs.getString(4));
				addbook.setPublisher(rs.getString(5));
				addbook.setYearofpub(rs.getString(6));
				lst.add(addbook);
			}
			//System.out.println(rs.getString(1));
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return lst;
	
	
}
	
	
	public void deleteBook(String bookId) {
		
		String sql1 = "SET foreign_key_checks = 0";
		String sql="delete from booksinventory where book_id = ?";
		String sql2 = "SET foreign_key_checks = 1";
		try(Connection conn = getConnection()){
			
			
			PreparedStatement pst1=conn.prepareStatement(sql1);
			ResultSet rs1 =pst1.executeQuery();
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, bookId);
			int row = pst.executeUpdate();
			
					if(row<0)
					{
						System.out.println("Book has not been deleted");
					}
					else
					{
						System.out.println("Book has  been deleted");
					}
			 
			 
			 PreparedStatement pst2=conn.prepareStatement(sql2);
				ResultSet rs2 =pst1.executeQuery();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
}
