package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;
import org.lib.bean.Users;

public class TransactionDaoImpl implements ITransactionDao{
	
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}

	@Override
	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration regid) {
		
		String sql = "insert into BooksTransaction values(?,?,?,?,?)";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement st=connection.prepareStatement(sql);
			st.setString(1, bookstransaction.getTransaction_id());
			st.setString(2, regid.getRegistration_id());
			st.setDate(3, java.sql.Date.valueOf(bookstransaction.getIssue_date()));
			st.setDate(4, java.sql.Date.valueOf(bookstransaction.getReturn_date()));
			st.setInt(5, bookstransaction.getFine());
			
			
			int row=st.executeUpdate();

			if(row>0)
				System.out.println("The Book has been collected from you and fine is calculated");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		
	}

	@Override
	public int findfine(String userid) {
		
		String sql = "select * from BooksTransaction where registration_id =?";
		
		try(Connection connection=getDbConnection())
		{
			
			int fine =0;
			PreparedStatement st=connection.prepareStatement(sql);
			ResultSet rs = st.executeQuery();
			fine =rs.getInt(5);

			return fine;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<BooksTransaction> getAllTransaction(BooksRegistration regid) {
		
		List<BooksTransaction> transaction =new ArrayList<>();
		String str="select * from BooksTransaction";
		String str1 ="select * from BooksRegistration";
		try(Connection connection=getDbConnection())
		{
			BooksRegistration reg = new BooksRegistration();
			PreparedStatement statement=connection.prepareStatement(str);
			PreparedStatement statement1=connection.prepareStatement(str1);
			
			ResultSet rs= statement.executeQuery();
			ResultSet rs1= statement1.executeQuery();
			
			
			while(rs1.next())
			{
				
				reg.setRegistration_id(rs1.getString(1));
				
			}
			
			
			while(rs.next())
			{
				BooksTransaction trans =new BooksTransaction();
				trans.setTransaction_id(rs.getString(1));
				trans.setRegistration_id(regid);
				trans.setIssue_date(rs.getDate(3).toLocalDate());
				trans.setReturn_date(rs.getDate(4).toLocalDate());
				trans.setFine(rs.getInt(5));
				transaction.add(trans);	
			
			}
		}	catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return transaction;
	}

}
