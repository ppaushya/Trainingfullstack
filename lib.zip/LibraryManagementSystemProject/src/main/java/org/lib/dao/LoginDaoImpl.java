package org.lib.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.bean.Users;

public class LoginDaoImpl implements ILoginDao{
	
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			//e.printStackTrace();
		}
		
		return null;
		
	}
	

	@Override
	public List<Users> getallusers() {
		
		List<Users> lst = new ArrayList<>();
		String str="select * from Users;";
		
		try(Connection connection=getDbConnection())
		{
			PreparedStatement statement=connection.prepareStatement(str);
			ResultSet rs= statement.executeQuery();
			
			
			while(rs.next())
			{
				Users user = new Users();
				user.setUser_id(rs.getString(1));
				user.setUser_name(rs.getString(2));
				user.setPassword(rs.getString(3));;
				user.setEmail_id(rs.getString(4));;
				user.setLibrarian(rs.getBoolean(5));;
				lst.add(user);
			}
		
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return lst;
	
	
}
	
	public boolean validStudent(String userName, String password, int c) {

		String sql="select * from users";
		try(Connection conn = getDbConnection()){
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rs =pst.executeQuery();
			 while(rs.next()) {
					if(rs.getString(2).equals(userName) && rs.getString(3).equals(password) && rs.getInt(5)==c)
					{
						return true;
					}
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
		
	}
	public boolean validLibrarian(String userNameLib, String passwordLib, int c) {
		String sql="select * from users";
		try(Connection conn = getDbConnection()){
			
			PreparedStatement pst=conn.prepareStatement(sql);
			ResultSet rs =pst.executeQuery();
			 while(rs.next()) {
					if(rs.getString(2).equals(userNameLib) && rs.getString(3).equals(passwordLib)&& rs.getInt(5)==c)
					{
						return true;
					}
			 }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
		
	}

}
