package org.lib.util;

import org.lib.bean.Users;

public class Utility {

	
	public static boolean isvaliduser(String userName)
	{
		 if(userName.matches("[a-zA-Z]+"))
		 {
			 
				 return true;
			 
		 }
		 return false;
	}
}

