package org.lib.service;

import java.util.List;

import org.lib.bean.BooksInventory;
import org.lib.bean.BooksRegistration;
import org.lib.bean.BooksTransaction;

public interface ITransactionService {

	public void doTransaction(BooksTransaction bookstransaction, BooksRegistration bookreg);
	public int findfine(String userid);

	public List<BooksTransaction> getAllTransaction(BooksRegistration regid);
	
}
