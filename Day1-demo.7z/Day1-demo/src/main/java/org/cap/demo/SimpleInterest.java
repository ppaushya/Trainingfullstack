package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {
		float principle;
		float rate;
		float simpleInterest;
		float time;
		public float si(float p, float t, float r)
		{
			float si;
			si=p*t*r/100;
			return si;
		}
		


}
