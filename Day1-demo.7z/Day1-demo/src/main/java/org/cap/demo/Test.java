package org.cap.demo;

public class Test {

	int count;
	char ch;
	boolean flag;
	static byte num=10;
	float pi;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Test obj=new Test();
		System.out.println(obj.count);
		System.out.println(obj.ch);
		System.out.println(obj.flag);
		System.out.println(obj.num);
		System.out.println(obj.pi);

	
		
		
		
	}

}
