package org.cap.demo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleInterest obj= new SimpleInterest();
		
		Scanner scanner= new Scanner(System.in);
		obj.principle=scanner.nextFloat();
		obj.time=scanner.nextFloat();
		obj.rate=scanner.nextFloat();
		obj.simpleInterest=obj.si(obj.principle,obj.time,obj.rate);
		System.out.println("Simple Interest: " + obj.simpleInterest);

	}
	
}
