//function performTrans(){
//	var flg=false;
//	var account=f2.accnt.value;
//	var choice=f2.choice.value;
//	var amount=f2.amount.value;
//	var des=f2.description.value;
//	var accnt=f2.accnt.value;
//	var 
//	//Array acc[]=
//}