package org.cap.demo;

import java.util.*;

public class employee {

	int empId;
	String empName;
	int age;
	boolean isPermanent;
	String gender;
	String address;
	
	public void getData()
	{
		Scanner scanner=new Scanner(System.in);
		
		System.out.println(" employee id");
			
		empId= scanner.nextInt();
		
		System.out.println(" name");
		
		empName= scanner.next();
		
		System.out.println(" age");
		
		age= scanner.nextInt();
		
		System.out.println("Permanent??");
		
		isPermanent= scanner.nextBoolean();
		
		System.out.println(" gender");
		
		gender= scanner.next();
		
System.out.println(" address");
		
		address= scanner.next();
		
		
	}
	
	public void printEmployee()
	{
		 System.out.println(empId);
		 System.out.println(empName);
		 System.out.println(age);
		 System.out.println(isPermanent);
		 System.out.println(gender);
		 System.out.println(address);
	}
	
	
	public static void main(String[] args) {
		
		employee emp=new employee();
		emp.getData();
		emp.printEmployee();	

	}

}