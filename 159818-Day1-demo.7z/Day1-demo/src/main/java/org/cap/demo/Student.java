package org.cap.demo;

import java.util.Scanner;

public class Student {

	String stuName;
	
	int marks1,marks2,marks3;
	
	public void getStudent()
	{
Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter student name");
			
		stuName= scanner.next();
		
		System.out.println("Enter marks1");
		
		marks1= scanner.nextInt();
		
		System.out.println("Enter marks 2");
		
		marks2= scanner.nextInt();
		
		System.out.println("Enter marks 3");
		
		marks3= scanner.nextInt();
	}
	
	public int findScore()
	{
		return marks1+marks2+marks3;
	}
	
	public int findAverage()
	{
		return (marks1+marks2+marks3)/3;
	}
	
	public void printStudent()
	{
		System.out.println("student name is "+stuName+" "+"student total marks is"+findScore()+" "+"student avg is "+findAverage());
		
	}
	public static void main(String[] args) {
		
		Student s=new Student();
		s.getStudent();
		System.out.println(s.findScore());
		System.out.println(s.findAverage());
		
         s.printStudent();
	}

}
