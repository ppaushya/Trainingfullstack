package org.cap.demo;

public class Test {
	
	int count;
	char ch;
	boolean flag;                                       
	byte number;
	float pi;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int mynum=100;
		
		
			Test obj=new Test();
			System.out.println(obj.ch);
			System.out.println(obj.flag);
			System.out.println(obj.count);
			System.out.println(obj.number);
			System.out.println(obj.pi);

			System.out.println("mynum="+mynum);
		
	}

}
