package org.cap.demo;

public class TestStatic {
	
	String name;
	static int count;
	final float pi=3.14f;
	
	public static void show()
	{
		System.out.println("Count:"+ count);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TestStatic obj=new TestStatic();
		obj.name="Tom";
		obj.count=10;
		
		System.out.println("Name:"+obj.name);
		System.out.println("Count:"+obj.count);
		
		System.out.println("Pi:" + obj.pi);
		
		TestStatic obj1=new TestStatic();
		obj1.name="Tommy";
		obj1.count=100;

		System.out.println("Name:"+obj1.name);
		System.out.println("Count:"+obj1.count);
	}

}
