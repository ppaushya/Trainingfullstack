package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {

	double principle;
	float years;
	float rateOfInterest;
	
	public void getData()
	{
//		principle=4000;
//		years=3.3f;
//		rateOfInterest=0.0665f;
		
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Princliple:");
		principle=scanner.nextDouble();
		System.out.println("Enter years:");

		years=scanner.nextFloat();
		
		System.out.println("Enter rate of interest:");
		rateOfInterest=scanner.nextFloat();

		scanner.close();
		
	}
	
	public double calculateInterest()
	{
		return principle*years*rateOfInterest;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
